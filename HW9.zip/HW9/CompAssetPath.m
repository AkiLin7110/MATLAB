%CompAssetPath.m
tic,paths = AssetPaths(50,0.1,0.3,1,100,10000);,toc; %迴圈
tic,paths = AssetPaths1(50,0.1,0.3,1,100,10000);,toc; %累加