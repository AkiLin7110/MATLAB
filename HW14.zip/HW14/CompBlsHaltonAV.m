%CompBlsHaltonAV.m
AsianHalton1000=AsianHalton(S0,X,r,T,sigma,NSamples,NRepl1);
AsianHalton2000=AsianHalton(S0,X,r,T,sigma,NSamples,NRepl2);
AsianHalton3000=AsianHalton(S0,X,r,T,sigma,NSamples,NRepl3);
AsianHalton10000=AsianHalton(S0,X,r,T,sigma,NSamples,NRepl4);
AsianHalton30000=AsianHalton(S0,X,r,T,sigma,NSamples,NRepl5);

AsianHalton1000
AsianHalton2000
AsianHalton3000
AsianHalton10000
AsianHalton30000
