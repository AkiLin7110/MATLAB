function d2 = fcn_d2(d1,sigma,t)
    d2 = d1-(sigma*sqrt(t));
end