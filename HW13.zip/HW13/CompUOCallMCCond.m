% CompUOCallMCCond.m Compare UOCalldiscrete, MC, MCCond
clear;
S0=52;
X=50;
r=0.1;
T=2/12;
sigma=0.4;
Sb1=30*exp(-0.5826*0.4*sqrt(1/12/30));
Sb2=30;
NStep=60;
NRepl=200000;
%DOPutdiscrete=DOPut(S0,X,r,T,sigma,Sb1);
randn('seed',0);
%clear min clear index;
[UOCallMC,CI1,NCrossed1]=UOCallMC(S0,X,r,T,sigma,Sb2,NStep,NRepl);
randn('seed',0);
[UOCallMCCond,CI2,NCrossed2]=UOCallMCCond(S0,X,r,T,sigma,Sb2,NStep,NRepl);

%DOPutdiscrete
UOCallMC
CI1
NCrossed1
UOCallMCCond
CI2
