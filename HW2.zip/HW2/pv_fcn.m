function d = pv_fcn(d,y)
    d = d*(1+y);  
end
