%ComputeDoPutHalton.m
S0=50;
X=50;
r=0.1;
T=2/12;
sigma=0.4;
NPoints = 10;
Base1 = 2;
Base2 = 3;
Sb = 30;
P = DoPutHalton(S0,X,r,T,sigma,NPoints,Base1,Base2,Sb);